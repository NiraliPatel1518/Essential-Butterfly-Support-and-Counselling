import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";
import { PublicFeatureProvider } from "../context/PublicFeatureContext";
import NewsletterSignup from "./NewsletterSignup";
afterEach(() => vi.unstubAllGlobals());
function mount(fetchMock: ReturnType<typeof vi.fn>) { vi.stubGlobal("fetch", fetchMock); return render(<MemoryRouter><PublicFeatureProvider><NewsletterSignup /></PublicFeatureProvider></MemoryRouter>); }
describe("NewsletterSignup", () => {
  it("renders when newsletter is enabled by default", async () => { mount(vi.fn().mockResolvedValue({ ok: true, json: async () => [] })); expect(await screen.findByRole("button", { name: /subscribe/i })).toBeInTheDocument(); });
  it("hides when newsletter is disabled", async () => { const f = vi.fn().mockResolvedValue({ ok: true, json: async () => [{ featureKey: "NEWSLETTER", enabled: false }] }); mount(f); await waitFor(() => expect(screen.queryByRole("button", { name: /subscribe/i })).not.toBeInTheDocument()); });
  it("submits an email with consent", async () => { const user = userEvent.setup(); const f = vi.fn().mockImplementation((url: string) => String(url).includes("/api/features") ? Promise.resolve({ ok: true, json: async () => [] }) : Promise.resolve({ ok: true, text: async () => "Subscription received." })); mount(f); const email = await screen.findByLabelText(/email/i); await user.type(email, "reader@example.com"); const check = screen.getByRole("checkbox"); await user.click(check); await user.click(screen.getByRole("button", { name: /subscribe/i })); await waitFor(() => expect(f.mock.calls.some(([url]) => String(url).includes("/api/newsletter/subscribe"))).toBe(true)); });
});
