import { describe, it, expect, afterEach, vi } from "vitest";
import { render, act } from "@testing-library/react";
import { MemoryRouter, Route, Routes, useLocation } from "react-router-dom";
import SessionTimeout from "./SessionTimeout";
function Probe() { const l = useLocation(); return <><SessionTimeout /><p>{l.pathname}{l.search}</p></>; }
afterEach(() => { vi.useRealTimers(); localStorage.clear(); });
describe("SessionTimeout", () => {
  it("does not start a timer without an authenticated session", () => { vi.useFakeTimers(); const spy = vi.spyOn(window, "setTimeout"); render(<MemoryRouter><Probe /></MemoryRouter>); expect(spy).not.toHaveBeenCalled(); });
  it("logs out a client after 30 minutes of inactivity", () => { vi.useFakeTimers(); localStorage.setItem("authToken", "client-token"); const { getByText } = render(<MemoryRouter initialEntries={["/client-dashboard"]}><Routes><Route path="*" element={<Probe />} /></Routes></MemoryRouter>); act(() => { vi.advanceTimersByTime(30 * 60 * 1000); }); expect(localStorage.getItem("authToken")).toBeNull(); expect(getByText("/login?sessionExpired=true")).toBeInTheDocument(); });
  it("logs out an admin after 30 minutes of inactivity", () => { vi.useFakeTimers(); localStorage.setItem("adminToken", "admin-token"); const { getByText } = render(<MemoryRouter initialEntries={["/admin-dashboard"]}><Routes><Route path="*" element={<Probe />} /></Routes></MemoryRouter>); act(() => { vi.advanceTimersByTime(30 * 60 * 1000); }); expect(localStorage.getItem("adminToken")).toBeNull(); expect(getByText("/admin-login?sessionExpired=true")).toBeInTheDocument(); });
});
