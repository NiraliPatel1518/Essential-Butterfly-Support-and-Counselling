import { describe, it, expect, vi, afterEach } from "vitest";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ForgotPassword from "./ForgotPassword";
import { renderApp } from "../test/render";
afterEach(() => vi.unstubAllGlobals());
describe("ForgotPassword", () => {
  it("renders recovery form", () => { vi.stubGlobal("fetch", vi.fn()); renderApp("/forgot-password", <ForgotPassword />); expect(screen.getByRole("heading", { name: /forgot your password/i })).toBeInTheDocument(); expect(screen.getByRole("button", { name: /send reset link/i })).toBeInTheDocument(); });
  it("requires an email before making a request", async () => { const f = vi.fn(); vi.stubGlobal("fetch", f); renderApp("/forgot-password", <ForgotPassword />); await userEvent.click(screen.getByRole("button", { name: /send reset link/i })); expect(f).not.toHaveBeenCalled(); });
  it("sends normalized email and shows confirmation", async () => { const f = vi.fn().mockResolvedValue({ ok: true, text: async () => "" }); vi.stubGlobal("fetch", f); renderApp("/forgot-password", <ForgotPassword />); await userEvent.type(screen.getByLabelText(/email address/i), " USER@EXAMPLE.COM "); await userEvent.click(screen.getByRole("button", { name: /send reset link/i })); expect(await screen.findByRole("status")).toHaveTextContent(/if an account exists/i); expect(f.mock.calls[0][0]).toContain("email=user%40example.com"); });
});
