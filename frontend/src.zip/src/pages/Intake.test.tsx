import { describe, expect, it, vi, afterEach } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Intake from "./Intake";
import { renderApp } from "../test/render";
afterEach(() => { vi.unstubAllGlobals(); localStorage.clear(); });
async function fillForm() { const u = userEvent.setup(); await u.type(screen.getByLabelText(/client.s full name/i), "Sam Lee"); await u.selectOptions(screen.getByLabelText(/preferred contact method/i), "email"); await u.type(screen.getByLabelText(/email address/i), "sam@example.com"); await u.type(screen.getByLabelText(/a little about your situation/i), "Overview"); await u.type(screen.getByLabelText(/what kind of support are you looking for/i), "Support needs"); return u; }
describe("Intake", () => {
  it("renders the current intake form", () => { vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => [] })); renderApp("/intake", <Intake />); expect(screen.getByRole("heading", { name: /let.s start with what matters to you/i })).toBeInTheDocument(); expect(screen.getByRole("button", { name: /submit intake request/i })).toBeInTheDocument(); });
  it("does not submit an empty form", async () => { const f = vi.fn(); vi.stubGlobal("fetch", f); renderApp("/intake", <Intake />); await userEvent.click(screen.getByRole("button", { name: /submit intake request/i })); expect(f).not.toHaveBeenCalled(); });
  it("sends valid intake data with client token", async () => { localStorage.setItem("authToken", "client.jwt"); const f = vi.fn().mockResolvedValue({ ok: true, text: async () => "Intake submitted" }); vi.stubGlobal("fetch", f); renderApp("/intake", <Intake />); const u = await fillForm(); await u.click(screen.getByRole("button", { name: /submit intake request/i })); await waitFor(() => expect(f).toHaveBeenCalledTimes(1)); expect(f.mock.calls[0][0]).toContain("/api/intake"); expect(f.mock.calls[0][1].headers.Authorization).toBe("Bearer client.jwt"); });
  it("shows backend error on unsuccessful submission", async () => { localStorage.setItem("authToken", "client.jwt"); const f = vi.fn().mockResolvedValue({ ok: false, text: async () => "Submission failed" }); vi.stubGlobal("fetch", f); renderApp("/intake", <Intake />); const u = await fillForm(); await u.click(screen.getByRole("button", { name: /submit intake request/i })); expect(await screen.findByRole("alert")).toHaveTextContent(/submission failed/i); });
});
