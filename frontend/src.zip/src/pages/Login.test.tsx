import { describe, it, expect, vi, afterEach } from "vitest";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Login from "./Login";
import { renderApp } from "../test/render";
afterEach(() => { vi.unstubAllGlobals(); localStorage.clear(); });
describe("Unified Login", () => {
  it("renders unified login form", () => { vi.stubGlobal("fetch", vi.fn()); renderApp("/login", <Login />); expect(screen.getByRole("heading", { name: /welcome back/i })).toBeInTheDocument(); expect(screen.getByLabelText(/email/i)).toBeInTheDocument(); expect(screen.getByLabelText(/password/i)).toBeInTheDocument(); });
  it("does not submit empty credentials", async () => { const f = vi.fn(); vi.stubGlobal("fetch", f); renderApp("/login", <Login />); await userEvent.click(screen.getByRole("button", { name: /sign in|login/i })); expect(f).not.toHaveBeenCalled(); });
  it("shows backend authentication errors", async () => { const f = vi.fn().mockResolvedValue({ ok: false, text: async () => "Invalid email or password" }); vi.stubGlobal("fetch", f); renderApp("/login", <Login />); await userEvent.type(screen.getByLabelText(/email/i), "user@example.com"); await userEvent.type(screen.getByLabelText(/password/i), "WrongPassword1"); await userEvent.click(screen.getByRole("button", { name: /sign in|login/i })); expect(await screen.findByRole("alert")).toHaveTextContent(/invalid email or password/i); });
});
