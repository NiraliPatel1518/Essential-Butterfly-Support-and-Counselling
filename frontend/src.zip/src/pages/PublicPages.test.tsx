import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Services from "./Services";
describe("Public information pages", () => {
  it("renders homepage content", () => { const { container } = render(<MemoryRouter><Home /></MemoryRouter>); expect(container.querySelector("main")).toBeInTheDocument(); });
  it("renders about page content", () => { const { container } = render(<MemoryRouter><About /></MemoryRouter>); expect(container.querySelector("main")).toBeInTheDocument(); });
  it("renders services page content", () => { const { container } = render(<MemoryRouter><Services /></MemoryRouter>); expect(container.querySelector("main")).toBeInTheDocument(); });
});
