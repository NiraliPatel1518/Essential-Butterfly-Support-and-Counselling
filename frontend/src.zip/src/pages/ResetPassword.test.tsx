import { describe, it, expect, vi, afterEach } from "vitest";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ResetPassword from "./ResetPassword";
import { renderApp } from "../test/render";
afterEach(() => vi.unstubAllGlobals());
describe("ResetPassword", () => {
  it("renders reset form", () => { vi.stubGlobal("fetch", vi.fn()); renderApp("/reset-password?token=abc", <ResetPassword />); expect(screen.getByRole("heading", { name: /reset your password/i })).toBeInTheDocument(); });
  it("rejects a missing token", async () => { const f = vi.fn(); vi.stubGlobal("fetch", f); renderApp("/reset-password", <ResetPassword />); await userEvent.type(screen.getByLabelText(/new password/i), "Password123"); await userEvent.type(screen.getByLabelText(/confirm password/i), "Password123"); await userEvent.click(screen.getByRole("button", { name: /reset password/i })); expect(await screen.findByRole("alert")).toHaveTextContent(/link is invalid/i); expect(f).not.toHaveBeenCalled(); });
  it("rejects mismatched passwords", async () => { const f = vi.fn(); vi.stubGlobal("fetch", f); renderApp("/reset-password?token=abc", <ResetPassword />); await userEvent.type(screen.getByLabelText(/new password/i), "Password123"); await userEvent.type(screen.getByLabelText(/confirm password/i), "Different123"); await userEvent.click(screen.getByRole("button", { name: /reset password/i })); expect(await screen.findByRole("alert")).toHaveTextContent(/passwords do not match/i); expect(f).not.toHaveBeenCalled(); });
  it("submits valid password reset", async () => { const f = vi.fn().mockResolvedValue({ ok: true, text: async () => "" }); vi.stubGlobal("fetch", f); renderApp("/reset-password?token=abc", <ResetPassword />); await userEvent.type(screen.getByLabelText(/new password/i), "Password123"); await userEvent.type(screen.getByLabelText(/confirm password/i), "Password123"); await userEvent.click(screen.getByRole("button", { name: /reset password/i })); expect(await screen.findByRole("status")).toHaveTextContent(/reset successfully/i); expect(JSON.parse(f.mock.calls[0][1].body)).toEqual({ token: "abc", newPassword: "Password123", confirmPassword: "Password123" }); });
});
