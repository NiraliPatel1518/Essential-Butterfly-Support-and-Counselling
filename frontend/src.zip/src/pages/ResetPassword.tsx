
import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { apiUrl } from "../api/api";
import "./ResetPassword.css";

function ResetPassword() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token") || "";

  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setMessage("");
    setError("");

    if (!token) {
      setError("This password reset link is invalid.");
      return;
    }

    if (!newPassword || !confirmPassword) {
      setError("Please enter and confirm your new password.");
      return;
    }

    if (newPassword.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(apiUrl("/api/password/reset"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token,
          newPassword,
          confirmPassword,
        }),
      });

      const data = await response.text();

      if (!response.ok) {
        setError(data || "Unable to reset your password.");
        return;
      }

      setMessage(
        "Your password has been reset successfully. You can now log in with your new password."
      );

      setNewPassword("");
      setConfirmPassword("");
    } catch (error) {
      console.error(error);
      setError(
        "Unable to connect to the server. Please make sure the backend is running."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="reset-password-page">
      <section className="reset-password-card">
        <div className="reset-password-content">
          <span className="reset-password-eyebrow">
            ACCOUNT RECOVERY
          </span>

          <h1>Reset your password</h1>

          <p className="reset-password-description">
            Create a new password for your Essential Butterfly account.
          </p>

          <form
            onSubmit={(event) => {
              event.preventDefault();
              void handleSubmit();
            }}
          >
            <div className="reset-password-field">
              <label htmlFor="newPassword">New Password</label>

              <input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(event) =>
                  setNewPassword(event.target.value)
                }
                placeholder="Enter your new password"
                autoComplete="new-password"
                required
                minLength={8}
                disabled={loading}
              />
            </div>

            <div className="reset-password-field">
              <label htmlFor="confirmPassword">
                Confirm Password
              </label>

              <input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(event) =>
                  setConfirmPassword(event.target.value)
                }
                placeholder="Confirm your new password"
                autoComplete="new-password"
                required
                minLength={8}
                disabled={loading}
              />
            </div>

            {error && (
              <p className="reset-password-error" role="alert">
                {error}
              </p>
            )}

            {message && (
              <p className="reset-password-success" role="status">
                {message}
              </p>
            )}

            <button
              type="submit"
              className="reset-password-button"
              disabled={loading}
            >
              {loading ? "Resetting..." : "Reset Password"}
            </button>
          </form>

          <Link
            to="/login"
            className="reset-password-back"
          >
            ← Back to Login
          </Link>
        </div>
      </section>
    </main>
  );
}

export default ResetPassword;
