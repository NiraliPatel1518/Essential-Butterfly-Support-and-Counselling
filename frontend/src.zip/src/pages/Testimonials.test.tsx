import { describe, it, expect, vi, afterEach } from "vitest";
import { screen } from "@testing-library/react";
import Testimonials from "./Testimonials";
import { renderApp } from "../test/render";
afterEach(() => vi.unstubAllGlobals());
describe("Testimonials", () => {
  it("loads public testimonials", async () => { const f = vi.fn().mockImplementation((url: string) => String(url).includes("/api/features") ? Promise.resolve({ ok: true, json: async () => [{ featureKey: "TESTIMONIALS", enabled: true }] }) : Promise.resolve({ ok: true, json: async () => [{ id: 1, displayName: "Community member", content: "A helpful experience", photos: [] }] })); vi.stubGlobal("fetch", f); renderApp("/testimonials", <Testimonials />); expect(await screen.findByText("Community member")).toBeInTheDocument(); });
  it("shows empty state when no testimonials are published", async () => { vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => [] })); renderApp("/testimonials", <Testimonials />); expect(await screen.findByText(/no published testimonials yet/i)).toBeInTheDocument(); });
});
